package com.dwi.filmid.core.utils

object Constanta {
    val AUTHORIZATION =
        "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4YmRiNGQyMjFiN2NhOTVhYTJjMGVhMzBiNmEzZGRhNCIsInN1YiI6IjYxZWYzMGIxZTlkYTY5MDA5NDhmYWE0ZiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.YnEtkwaAjIcH4qqlwZeOXo-y2fYRM-q1P6dMZMdiGGQ"
    val BASE_URL = "https://api.themoviedb.org/3/"
    val IMAGE_URL = "https://image.tmdb.org/t/p/original/"
}